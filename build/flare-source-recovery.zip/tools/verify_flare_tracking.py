"""Verify scoped flare hooks and wrist/light calls in all four supported DLLs."""
from pathlib import Path
import struct
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

root = Path(__file__).resolve().parents[1]
source = (root / "src/FirstPerson.cpp").read_text()
builds = (
    ("PDB/tomb4.dll", 0x696B4999, 0x5F7F0, 0xA3920, 0xA37C0, 0x5F490),
    ("PDB/tomb5.dll", 0x696B499C, 0x5C9D0, 0x9CB20, 0x9C9C0, 0x5C670),
    ("retail/tomb4.dll", 0x68C12FDA, 0x5F500, 0xA44C0, 0xA4360, 0x5F1A0),
    ("retail/tomb5.dll", 0x68C12FE9, 0x5D700, 0x9CE90, 0x9CD30, 0x5D3A0),
)
decoder = Cs(CS_ARCH_X86, CS_MODE_64)
for name, stamp, hand, previous, joint, light in builds:
    pe = pefile.PE(str(root / name))
    data = pe.get_memory_mapped_image()
    assert pe.FILE_HEADER.TimeDateStamp == stamp
    assert f"{{0x{stamp:X},0x{hand:X},0x{previous:X}}}" in source
    for rva, code in ((hand, "40534883ec40"), (previous, "48895c2408")):
        prefix = bytes.fromhex(code)
        assert data[rva:rva + len(prefix)] == prefix, (name, "hook prologue")
        instructions = list(decoder.disasm(prefix, rva))
        assert sum(i.size for i in instructions) == len(prefix)
        assert all("rip" not in i.op_str and not i.mnemonic.startswith("j") for i in instructions)
    # Both games query current and previous LEFT wrist (13) with the same HD
    # tip offset (11,-64,41), then call the original light routine with hand=1.
    instructions = list(decoder.disasm(data[hand:hand + 0x91], hand))
    calls = []
    for ins in instructions:
        if ins.mnemonic == "call" and data[ins.address] == 0xE8:
            calls.append(ins.address + 5 + struct.unpack_from("<i", data, ins.address + 1)[0])
    assert calls == [joint, previous, light], (name, calls)
    operands = "\n".join(i.op_str for i in instructions)
    for expected in ("ecx, 0xffffffc0", "eax, 0x20", "r8d, 0xd", "r9d, 1"):
        assert expected in operands, (name, expected)
    assert "r8d, [rcx + 0x4d]" in operands or operands.count("r8d, 0xd") == 2
    assert "0xb" in operands and "0x29" in operands
    print(f"{name}: hook boundaries, current/previous left wrist, HD flare tip and native light call verified")
